Export generati da PDF Blue e Purple caricati in chat.

Contenuto:
- Blue: 200 righe in ordine originale visibile nei PDF
- Purple: 200 righe in ordine originale visibile nei PDF
- Combined: 400 righe

Formati:
- CSV: colonne hebrew, english, level, page, row_on_page
- TSV Hebrew-English: una carta per riga, Hebrew<TAB>English
- TSV English-Hebrew: una carta per riga, English<TAB>Hebrew
- TXT Quizlet testuale: identico al TSV, pronto per copia/incolla o importazione Quizlet

Nota: i PDF erano immagini senza testo estraibile; l'export è stato ricostruito tramite OCR dalle pagine renderizzate.
